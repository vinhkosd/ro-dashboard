<?php
session_destroy();
?>
<script type="text/javascript">
window.location = "<?php homePath()?>";
</script>