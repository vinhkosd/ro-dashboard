<?php
    define('DB_CONNECTION', 'mysql');
    define('DB_HOST', '103.92.25.253');
    define('DB_PORT', '3306');
    define('DB_DATABASE', 'mygame');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '123456');

    define('DB_CONNECTION_GLOBAL', 'mysql');
    define('DB_HOST_GLOBAL', '103.92.25.253');
    define('DB_PORT_GLOBAL', '3306');
    define('DB_DATABASE_GLOBAL', 'ro_global');
    define('DB_USERNAME_GLOBAL', 'root');
    define('DB_PASSWORD_GLOBAL', '123456');

    define('DB_CONNECTION_GAME', 'mysql');
    define('DB_HOST_GAME', '103.92.25.253');
    define('DB_PORT_GAME', '3306');
    define('DB_DATABASE_GAME', 'ro_xd_r2');
    define('DB_USERNAME_GAME', 'root');
    define('DB_PASSWORD_GAME', '123456');
?>